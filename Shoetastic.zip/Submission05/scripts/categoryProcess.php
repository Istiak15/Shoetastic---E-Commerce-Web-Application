<?php
// Get the category code from the URL parameter
$categoryCode = $_GET['categoryCode'];

// SQL query to select products belonging to the specified category, ordered by name
$query = "SELECT * 
          FROM my_Product 
          WHERE catCode = '$categoryCode' 
          ORDER BY name ASC";  

// Execute the query
$category = mysqli_query($db, $query);

// Get the number of records returned
$numRecords = mysqli_num_rows($category);

// Output the table structure and headers
echo "<div style ='overflow-x:auto;'>
<table class='w3-table w3-border w3-bordered'>
    <tr>
        <th>Product Image</th>
        <th>Product Name</th>
        <th>Price</th>
        <th># in Stock</th>
        <th>Purchase?</th>
    </tr>";

// Loop through each record in the result set
for ($i = 1; $i <= $numRecords; $i++) {
    $row = mysqli_fetch_array($category, MYSQLI_ASSOC);
    $productImageFile = $row['image_file'];
    $productName = $row['name'];
    $productPrice = $row['price'];
    $productPriceAsString = sprintf("$%.2f", $productPrice);
    $productQuantity = $row['quantity']; 
    $productID = $row['product_id'];
    
    // Output table row with product details
    echo
    "<tr> 
        <td class='w3-left-align'>
            <img width='70'
            src='images/products/$productImageFile'
            alt='Product Image'>
        </td>
        <td>$productName</td>
        <td class='w3-left-align'>$productPriceAsString</td>
        <td class='w3-center' style='position:relative;left:-3%;'>$productQuantity</td>
        <td>
            <a class='w3-button w3-teal w3-round w3-small'
               title='Not Yet Active'
               href='pages/checkout.php'>
                Buy this item
            </a>
        </td>
    </tr>";
}

// Close the table structure
echo "</table></div>";

// Close the database connection
mysqli_close($db);
?>
